Tests
=====

SOme of these tests can be run from this directory without server support.

Create a symlink for the forge code:

    $ ln -s ../js forge

Load the `index.html` file in a browser.
