package org.votingsystem.model;

public interface MessageVS {

}
