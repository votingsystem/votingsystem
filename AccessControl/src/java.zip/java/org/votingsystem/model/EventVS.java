package org.votingsystem.model;


public interface EventVS {

}
