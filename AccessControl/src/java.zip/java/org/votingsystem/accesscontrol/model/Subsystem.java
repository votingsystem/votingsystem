package org.votingsystem.accesscontrol.model;

public enum Subsystem {

	VOTES, CLAIMS, MANIFESTS, REPRESENTATIVES;
}
