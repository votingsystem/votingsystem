package org.votingsystem.accesscontrol.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.log4j.Logger;


/**
* @author jgzornoza
* Licencia: https://github.com/jgzornoza/SistemaVotacion/wiki/Licencia
*/
@Entity
@Table(name="RepresentationDocument")
public class RepresentationDocument implements Serializable {
	
	public enum State {OK, CANCELLED, CANCELLED_BY_REPRESENTATIVE, ERROR}
	
    private static final long serialVersionUID = 1L;
    
    private static Logger log = Logger.getLogger(RepresentationDocument.class);
    
    @Id @GeneratedValue(strategy=IDENTITY)
    @Column(name="id", unique=true, nullable=false)
    private Long id;
    @Enumerated(EnumType.STRING)
    @Column(name="state", nullable=false)
    private State state;
    @OneToOne
    @JoinColumn(name="activationSMIMEId")
    private MessageSMIME activationSMIME;
	
    @OneToOne
    @JoinColumn(name="cancellationSMIMEId")
    private MessageSMIME cancellationSMIME;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="userId")
    private Usuario user;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="representativeId")
    private Usuario representative;
	
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="fechaCancelacion", length=23)
    private Date dateCanceled;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="fechaCreacion", length=23)
    private Date dateCreated;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="fechaActualizacion", length=23)
    private Date lastUpdated;

	public Date getDateCanceled() {
		return dateCanceled;
	}

	public void setDateCanceled(Date dateCanceled) {
		this.dateCanceled = dateCanceled;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public MessageSMIME getActivationSMIME() {
		return activationSMIME;
	}

	public void setActivationSMIME(MessageSMIME activationSMIME) {
		this.activationSMIME = activationSMIME;
	}

	public MessageSMIME getCancellationSMIME() {
		return cancellationSMIME;
	}

	public void setCancellationSMIME(MessageSMIME cancellationSMIME) {
		this.cancellationSMIME = cancellationSMIME;
	}

	public Usuario getRepresentative() {
		return representative;
	}

	public void setRepresentative(Usuario representative) {
		this.representative = representative;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public Usuario getUser() {
		return user;
	}

	public void setUser(Usuario user) {
		this.user = user;
	}
}
