package org.votingsystem.signature.util;

import java.security.cert.X509Certificate;
import java.util.Properties;

import javax.mail.Session;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.votingsystem.model.UserVS;

public class ContextVS {

    public static final Session MAIL_SESSION = Session.getDefaultInstance(
    		System.getProperties(), null);
    
    
    public static final String MULTISIGNED_FILE_NAME = "MultiSign";
	public static final String PROVIDER = BouncyCastleProvider.PROVIDER_NAME;
    //smime.p7m -> Email message encrypted
    //smime.p7s -> Email message that includes a digital signature
    public static final String SIGNED_PART_EXTENSION = ".p7s";
    public static final String DEFAULT_SIGNED_FILE_NAME = "smimeMessage.p7m";
    
    private static String userVSClassName = null;
    
    public static void setUserVSClassName(String className) {
    	userVSClassName = className;
    }
    
    public static UserVS getUserVS(X509Certificate certificate) throws 
    	ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class userVSClass = Class.forName(userVSClassName);
        UserVS userVS = (UserVS)userVSClass.newInstance();
    	userVS.setCertificate(certificate);
    	String subjectDN = certificate.getSubjectDN().getName();
    	if (subjectDN.contains("C="))
    		userVS.setPais(subjectDN.split("C=")[1].split(",")[0]);
    	if (subjectDN.contains("SERIALNUMBER="))
    		userVS.setNif(subjectDN.split("SERIALNUMBER=")[1].split(",")[0]);
    	if (subjectDN.contains("SURNAME="))
    		userVS.setPrimerApellido(subjectDN.split("SURNAME=")[1].split(",")[0]);
    	if (subjectDN.contains("GIVENNAME="))
    		userVS.setNombre(subjectDN.split("GIVENNAME=")[1].split(",")[0]);
    	if (subjectDN.contains("CN="))
    		userVS.setCn(subjectDN.split("CN=")[1]);
		if(subjectDN.split("OU=email:").length > 1) {
			userVS.setEmail(subjectDN.split("OU=email:")[1].split(",")[0]);
		}
		if(subjectDN.split("CN=nif:").length > 1) {
			String nif = subjectDN.split("CN=nif:")[1];
			if (nif.split(",").length > 1) {
				nif = nif.split(",")[0];
			}
			userVS.setNif(nif);
		}
		if (subjectDN.split("OU=telefono:").length > 1) {
			userVS.setTelefono(subjectDN.split("OU=telefono:")[1].split(",")[0]);
		}
    	return userVS;    
    }
    
    public static UserVS getUserVS() throws 
		ClassNotFoundException, InstantiationException, IllegalAccessException {
	    Class userVSClass = Class.forName(userVSClassName);
	    UserVS userVS = (UserVS)userVSClass.newInstance();
		return userVS;    
	}
    
}
